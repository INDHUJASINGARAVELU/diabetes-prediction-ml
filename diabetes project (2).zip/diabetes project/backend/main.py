from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import joblib
import sqlite3
import numpy as np

# -----------------------------
# CREATE FASTAPI APP
# -----------------------------
app = FastAPI(title="Diabetes Risk Prediction API")

# -----------------------------
# STEP 1 & STEP 2: ENABLE CORS
# -----------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Allow all frontends
    allow_credentials=True,
    allow_methods=["*"],          # Allow POST, GET, OPTIONS
    allow_headers=["*"],
)

# -----------------------------
# LOAD MODEL & SCALER
# -----------------------------
model = joblib.load("diabetes_random_forest_balanced.pkl")
scaler = joblib.load("scaler.pkl")

# -----------------------------
# DATABASE SETUP (SQLite)
# -----------------------------
conn = sqlite3.connect("predictions.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    age INTEGER,
    gender INTEGER,
    glucose REAL,
    bmi REAL,
    systolic_bp INTEGER,
    risk_probability REAL,
    prediction TEXT
)
""")
conn.commit()

# -----------------------------
# INPUT SCHEMA
# -----------------------------
class PatientInput(BaseModel):
    age: int
    gender: int
    pulse_rate: int
    systolic_bp: int
    diastolic_bp: int
    glucose: float
    height: float
    weight: float
    bmi: float
    family_diabetes: int
    hypertensive: int
    family_hypertension: int
    cardiovascular_disease: int
    stroke: int

# -----------------------------
# HOME ROUTE
# -----------------------------
@app.get("/")
def home():
    return {"message": "Diabetes Prediction API is running"}

# -----------------------------
# PREDICTION ROUTE
# -----------------------------
@app.post("/predict")
def predict(data: PatientInput):

    features = np.array([[ 
        data.age,
        data.gender,
        data.pulse_rate,
        data.systolic_bp,
        data.diastolic_bp,
        data.glucose,
        data.height,
        data.weight,
        data.bmi,
        data.family_diabetes,
        data.hypertensive,
        data.family_hypertension,
        data.cardiovascular_disease,
        data.stroke
    ]])

    scaled_features = scaler.transform(features)
    probability = model.predict_proba(scaled_features)[0][1]

    prediction = "Yes" if probability >= 0.35 else "No"

    # -----------------------------
    # STORE DATA IN DATABASE
    # -----------------------------
    cursor.execute("""
        INSERT INTO predictions 
        (age, gender, glucose, bmi, systolic_bp, risk_probability, prediction)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        data.age,
        data.gender,
        data.glucose,
        data.bmi,
        data.systolic_bp,
        round(probability, 2),
        prediction
    ))
    conn.commit()

    return {
        "diabetes": prediction,
        "risk_probability": round(probability, 2)
    }

# -----------------------------
# VIEW STORED RECORDS
# -----------------------------
@app.get("/records")
def get_records():
    cursor.execute("SELECT * FROM predictions")
    rows = cursor.fetchall()

    records = []
    for row in rows:
        records.append({
            "id": row[0],
            "age": row[1],
            "gender": row[2],
            "glucose": row[3],
            "bmi": row[4],
            "systolic_bp": row[5],
            "risk_probability": row[6],
            "prediction": row[7]
        })

    return records
