// -----------------------------
// AUTO BMI CALCULATION
// -----------------------------
function calculateBMI() {
    const height = Number(document.getElementById("height").value);
    const weight = Number(document.getElementById("weight").value);

    if (height > 0 && weight > 0) {
        const heightMeters = height / 100;
        const bmi = weight / (heightMeters * heightMeters);
        document.getElementById("bmi").value = bmi.toFixed(1);
    }
}

// -----------------------------
// PREDICT FUNCTION
// -----------------------------
function predict() {

    const age = Number(document.getElementById("age").value);
    const gender = Number(document.getElementById("gender").value);
    const pulse = Number(document.getElementById("pulse_rate").value);
    const systolic = Number(document.getElementById("systolic_bp").value);
    const diastolic = Number(document.getElementById("diastolic_bp").value);
    const glucose = Number(document.getElementById("glucose").value);
    const height = Number(document.getElementById("height").value);
    const weight = Number(document.getElementById("weight").value);
    const bmi = Number(document.getElementById("bmi").value);

    if (!bmi) {
        alert("Please enter height and weight to calculate BMI");
        return;
    }

    const hypertensive = (systolic >= 140 || diastolic >= 90) ? 1 : 0;

    const data = {
        age,
        gender,
        pulse_rate: pulse,
        systolic_bp: systolic,
        diastolic_bp: diastolic,
        glucose,
        height,
        weight,
        bmi,
        family_diabetes: 1,
        hypertensive,
        family_hypertension: hypertensive,
        cardiovascular_disease: 0,
        stroke: 0
    };

    fetch("http://127.0.0.1:8000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {

        const prob = result.risk_probability;
        const percent = Math.round(prob * 100);

        let color = "green";
        let level = "Low Risk 🟢";
        let warning = "You are currently at low risk.";
        let recommendation = "Maintain a healthy lifestyle.";

        if (glucose >= 200 || bmi >= 30 || systolic >= 160) {
            color = "red";
            level = "High Risk 🔴";
            warning = "⚠️ High clinical indicators detected.";
            recommendation = "Immediate medical consultation is recommended.";
        }
        else if (prob >= 0.35) {
            color = "orange";
            level = "Medium Risk 🟠";
            warning = "⚠️ Moderate diabetes risk detected.";
            recommendation = "Lifestyle changes and regular monitoring advised.";
        }

        document.getElementById("result").innerHTML =
            `Prediction: <b>${result.diabetes}</b><br>
             Risk Probability: <b>${percent}%</b>`;

        const bar = document.getElementById("progress-bar");
        bar.style.width = percent + "%";
        bar.style.background = color;

        document.getElementById("risk-level").innerText = level;
        document.getElementById("risk-level").style.color = color;

        document.getElementById("doctor-warning").innerText = warning;
        document.getElementById("doctor-warning").style.color = color;

        document.getElementById("recommendation-box").innerText = recommendation;
    })
    .catch(() => {
        document.getElementById("result").innerText =
            "❌ Backend not reachable. Please start the server.";
    });
}

// -----------------------------
// CONSULTATION NAVIGATION
// -----------------------------
function goToConsultation() {
    window.location.href = "consultation.html";
}
